#include <iostream>
using namespace std; 

int main() {

    int side1, side2, side3;
    cout<<"Enter side1: ";
    cin>>side1;
    cout<<"Enter side2: ";
    cin>>side2;
    cout<<"Enter side3: ";
    cin>>side3;
    
    if (side1 == side2 && side1 == side3 && side2 == side3) {
        cout<<"Equilateral triangle ";
    }else if (side1 == side2 || side1 == side3 || side2 == side3) {
        cout<<"Isosceles triangle ";
    }else if (side1 != side2 && side1 != side3 && side2 != side3) {
        cout<<"Scalene triangle ";
    }

}
