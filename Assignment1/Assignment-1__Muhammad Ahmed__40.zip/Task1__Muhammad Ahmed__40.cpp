#include<isostream>
using namespace std;
 int main() {
    int a, c, x, y;
    cout<<"Enter value of a: ";
    cin>>a;
    cout<<"Enter bvalue of x: ";
    cin>>x;
    cout<<"Enter value of c: ";
    cin>>c;
    y = (a*x) + c;
    cout<<"Value of y: " << y;
}