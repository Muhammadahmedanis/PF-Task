#include<iostream>
using namespace std;

int main() {
    float a, b;
    cout<<"Enter a: ";
    cin>>a;
    cout<<"Enter b: ";
    cin>>b;
    int c = a * b;
    cout<<"Value of c: " <<c;
}